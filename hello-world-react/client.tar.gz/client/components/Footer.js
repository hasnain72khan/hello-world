import React from 'react';


export default class Footer extends React.Component {
  render() {
    return (
     
      <div>
      <footer>
      <p>Copyright &copy; Blog</p>
      </footer>      
     </div>
    
     );
  }
}