import React from 'react';
import $ from 'jquery';


export default class Register extends React.Component {
	 constructor(props) {
    super(props)
    this.registerSubmit = this.registerSubmit.bind(this);
}
 registerSubmit(e) {
  e.preventDefault();

  $.ajax({
    url:'http://laravel.renegade.local/api/login',
    dataType: 'json',
    data: {
    	first: this.refs.f_name.value,
    	last: this.refs.l_name.value,
        email: this.refs.email.value,
        password: this.refs.password.value
    },
    cache: false,
    success: function(data){
       console.log(data);
    }
  }); 
};
  render() {
    return (
    
      <div className="Login-content">
      <form onSubmit= {this.registerSubmit}>
      <h2>Registeration form</h2>
       <div className="inputBox">
        <label>First Name:</label>
        <input type="text" ref="f_name" required/>
       </div>
       <div className="inputBox">
        <label>Last Name:</label>
        <input type="text" ref="l_name" required/>
       </div>
       <div className="inputBox">
        <label>Email:</label>
        <input type="email" ref="email" required/>
       </div>
       <div className="inputBox">
        <label>Password:</label>
        <input type="password" ref="password" required/>
       </div>
       <div className="inputBox">
        <button>Submit</button>
       </div>
       </form>
     </div>
    
     );
  }
}